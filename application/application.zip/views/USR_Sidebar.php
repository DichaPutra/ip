<!-- Sidebar Menu -->
<ul class="sidebar-menu">
    <li class="header">Admin KPI</li>
    <!-- Optionally, you can add icons to the links -->
    <li><a href="<?php echo base_url(); ?>index.php/USR_Scoring_c"><i class="fa fa-area-chart"></i> <span>Scoring</span></a></li>
    <!--<li><a href="#"><i class="fa fa-tasks"></i> <span>Nilai KKP</span></a></li>-->

    <!--    <li class="treeview">
            <a href="#"><i class="fa fa-area-chart"></i> <span>Score Monitoring</span>
                <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                </span>
            </a>
            <ul class="treeview-menu">
                <li><a href="<?php // echo base_url();  ?>index.php/KPI_planningscore_c">Planning Score</a></li>
                <li><a href="<?php // echo base_url();  ?>index.php/KPI_realizationscore_c">Realization Score</a></li>
            </ul>
        </li>-->
    <!--<li><a href="kpi_planningscore.php"><i class="fa fa-area-chart"></i> <span>Planning Score</span></a></li>-->
    <!--<li><a href="<?php // echo base_url();  ?>index.php/KPI_improvementplanning_c"><i class="fa fa-check-circle"></i> <span>Improvement Planning</span></a></li>
    <li><a href="<?php // echo base_url();  ?>index.php/KPI_realizationprogress_c"><i class="fa fa-check-circle"></i> <span>Realization Progress</span></a></li>-->

<!--    <li class="header">Settings</li>
    <li><a href="<?php echo base_url(); ?>index.php/ADM_Relasi_c"><i class="fa fa-sitemap"></i> <span>Relasi Penilaian</span></a></li>
    <li><a href="<?php echo base_url(); ?>index.php/ADM_Kuisioner_c"><i class="fa fa-check-circle"></i> <span>Kuisioner</span></a></li>
    <li><a href="<?php echo base_url(); ?>index.php/ADM_Account_c"><i class="fa fa-user"></i> <span>Account</span></a></li>-->

    <li class="header"></li>
    <li><a href="<?php echo base_url(); ?>index.php/logout"><i class="fa fa-sign-out"></i> <span>Signout</span></a></li>
</ul>
<!-- /.sidebar-menu -->