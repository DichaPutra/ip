<!-- Sidebar Menu -->
<ul class="sidebar-menu">
    <li class="header">Department Level</li>
    <!-- Optionally, you can add icons to the links -->
    <li><a href="<?php echo base_url(); ?>index.php/DEP_rencanaimprovement_c"><i class="fa fa-area-chart"></i> <span>Rencana Improvement</span></a></li>
    <li><a href="<?php echo base_url(); ?>index.php/DEP_kendalarealisasi_c"><i class="fa fa-check-circle"></i> <span>Kendala Realisasi</span></a></li>
    <li><a href="<?php echo base_url(); ?>index.php/logout"><i class="fa fa-sign-out"></i> <span>Signout</span></a></li>
</ul>
<!-- /.sidebar-menu -->